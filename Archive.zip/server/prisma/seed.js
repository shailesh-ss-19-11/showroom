import "dotenv/config";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const bikeCount = await prisma.bike.count();
  if (bikeCount === 0) {
    const bike = await prisma.bike.create({
      data: {
        name: "FZ-S FI V4",
        brand: "Yamaha",
        category: "Sport",
        price: 128900,
        engineCC: 149,
        mileageKmpl: 45,
        topSpeedKmph: 114,
        power: "12.2 PS @ 7250 rpm",
        transmission: "5-speed manual",
        description: "A street-fighter styled sports commuter with aggressive stance and refined performance.",
        featured: true,
        colors: {
          create: [
            { name: "Metallic Black", hexCode: "#1a1a1a" },
            { name: "Racing Blue", hexCode: "#1e3a8a" },
          ],
        },
      },
    });
    console.log(`Created sample bike ${bike.name}`);
  } else {
    console.log("Bikes already exist, skipping sample data.");
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
