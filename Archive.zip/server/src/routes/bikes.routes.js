import { Router } from "express";
import { requireAdmin } from "../middleware/auth.js";
import { upload } from "../middleware/upload.js";
import {
  listBikes,
  getBike,
  getMeta,
  createBike,
  updateBike,
  deleteBike,
  addColor,
  deleteColor,
  addImage,
  deleteImage,
} from "../controllers/bikes.controller.js";

const router = Router();

router.get("/meta", getMeta);
router.get("/", listBikes);
router.get("/:id", getBike);

router.post("/", requireAdmin, upload.array("images", 10), createBike);
router.put("/:id", requireAdmin, updateBike);
router.delete("/:id", requireAdmin, deleteBike);

router.post("/:id/colors", requireAdmin, addColor);
router.delete("/:id/colors/:colorId", requireAdmin, deleteColor);

router.post("/:id/images", requireAdmin, addImage);
router.delete("/:id/images/:imageId", requireAdmin, deleteImage);

export default router;
