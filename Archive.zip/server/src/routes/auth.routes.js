import { Router } from "express";
import jwt from "jsonwebtoken";
import { requireAdmin } from "../middleware/auth.js";

const router = Router();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Admin@123";

router.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: "Username and password are required" });
  }

  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Invalid username or password" });
  }

  const token = jwt.sign({ username: ADMIN_USERNAME }, process.env.JWT_SECRET, {
    expiresIn: "7d",
  });

  res.json({ token, admin: { username: ADMIN_USERNAME } });
});

router.get("/me", requireAdmin, (req, res) => {
  res.json({ admin: req.admin });
});

export default router;
