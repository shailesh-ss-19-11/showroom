import { Router } from "express";
import prisma from "../prisma/client.js";
import { requireAdmin } from "../middleware/auth.js";

const router = Router();

router.post("/", async (req, res) => {
  const { name, phone, email, message, bikeId, source } = req.body;
  if (!name || !phone) {
    return res.status(400).json({ error: "name and phone are required" });
  }
  const enquiry = await prisma.enquiry.create({
    data: {
      name,
      phone,
      email: email ?? null,
      message: message ?? null,
      bikeId: bikeId ?? null,
      source: source ?? "contact",
    },
  });
  res.status(201).json(enquiry);
});

router.get("/", requireAdmin, async (req, res) => {
  const { bikeId } = req.query;
  const enquiries = await prisma.enquiry.findMany({
    where: bikeId ? { bikeId } : undefined,
    include: { bike: { select: { id: true, name: true, brand: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json(enquiries);
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    await prisma.enquiry.delete({ where: { id: req.params.id } });
    res.status(204).end();
  } catch {
    res.status(404).json({ error: "Enquiry not found" });
  }
});

export default router;
