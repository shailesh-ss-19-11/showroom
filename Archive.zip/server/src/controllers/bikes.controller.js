import prisma from "../prisma/client.js";
import { generateKey, uploadObject, deleteObject, keyFromUrl } from "../storage/garage.js";
import { buildFileUrl } from "../utils/publicUrl.js";

const bikeInclude = {
  colors: true,
  images: { orderBy: [{ isPrimary: "desc" }, { createdAt: "asc" }] },
};

export async function listBikes(req, res) {
  const { brand, category, search, minPrice, maxPrice, featured, sort } = req.query;

  const where = { isActive: true };
  if (brand) where.brand = { equals: brand, mode: "insensitive" };
  if (category) where.category = { equals: category, mode: "insensitive" };
  if (featured === "true") where.featured = true;
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { brand: { contains: search, mode: "insensitive" } },
    ];
  }
  if (minPrice || maxPrice) {
    where.price = {};
    if (minPrice) where.price.gte = Number(minPrice);
    if (maxPrice) where.price.lte = Number(maxPrice);
  }

  const orderBy =
    sort === "price_asc"
      ? { price: "asc" }
      : sort === "price_desc"
        ? { price: "desc" }
        : { createdAt: "desc" };

  const bikes = await prisma.bike.findMany({ where, include: bikeInclude, orderBy });
  res.json(bikes);
}

export async function getBike(req, res) {
  const bike = await prisma.bike.findUnique({
    where: { id: req.params.id },
    include: bikeInclude,
  });
  if (!bike) return res.status(404).json({ error: "Bike not found" });
  res.json(bike);
}

export async function getMeta(_req, res) {
  const bikes = await prisma.bike.findMany({
    where: { isActive: true },
    select: { brand: true, category: true },
  });
  const brands = [...new Set(bikes.map((b) => b.brand))].sort();
  const categories = [...new Set(bikes.map((b) => b.category))].sort();
  res.json({ brands, categories });
}

function toNumberOrNull(value) {
  if (value === undefined || value === null || value === "") return null;
  const num = Number(value);
  return Number.isNaN(num) ? null : num;
}

function toBoolean(value) {
  return value === true || value === "true" || value === "on" || value === "1";
}

export async function createBike(req, res, next) {
  const {
    name,
    brand,
    category,
    price,
    engineCC,
    mileageKmpl,
    topSpeedKmph,
    power,
    transmission,
    description,
    featured,
  } = req.body;

  if (!name || !brand || !category || price === undefined || price === "") {
    return res.status(400).json({ error: "name, brand, category and price are required" });
  }

  const files = req.files || [];

  try {
    const uploaded = await Promise.all(
      files.map(async (file) => {
        const key = generateKey(file.originalname);
        await uploadObject(key, file.buffer, file.mimetype);
        return buildFileUrl(key);
      })
    );

    const bike = await prisma.bike.create({
      data: {
        name,
        brand,
        category,
        price: toNumberOrNull(price),
        engineCC: toNumberOrNull(engineCC),
        mileageKmpl: toNumberOrNull(mileageKmpl),
        topSpeedKmph: toNumberOrNull(topSpeedKmph),
        power: power ?? null,
        transmission: transmission ?? null,
        description: description ?? null,
        featured: toBoolean(featured),
        images: {
          create: uploaded.map((url, index) => ({
            url,
            isPrimary: index === 0,
          })),
        },
      },
      include: bikeInclude,
    });
    res.status(201).json(bike);
  } catch (err) {
    next(err);
  }
}

export async function updateBike(req, res) {
  const {
    name,
    brand,
    category,
    price,
    engineCC,
    mileageKmpl,
    topSpeedKmph,
    power,
    transmission,
    description,
    featured,
    isActive,
  } = req.body;

  try {
    const bike = await prisma.bike.update({
      where: { id: req.params.id },
      data: {
        ...(name !== undefined && { name }),
        ...(brand !== undefined && { brand }),
        ...(category !== undefined && { category }),
        ...(price !== undefined && { price }),
        ...(engineCC !== undefined && { engineCC }),
        ...(mileageKmpl !== undefined && { mileageKmpl }),
        ...(topSpeedKmph !== undefined && { topSpeedKmph }),
        ...(power !== undefined && { power }),
        ...(transmission !== undefined && { transmission }),
        ...(description !== undefined && { description }),
        ...(featured !== undefined && { featured: Boolean(featured) }),
        ...(isActive !== undefined && { isActive: Boolean(isActive) }),
      },
      include: bikeInclude,
    });
    res.json(bike);
  } catch {
    res.status(404).json({ error: "Bike not found" });
  }
}

export async function deleteBike(req, res) {
  try {
    const bike = await prisma.bike.delete({
      where: { id: req.params.id },
      include: { images: true },
    });
    await Promise.all(
      bike.images.map((img) => {
        const key = keyFromUrl(img.url);
        return key
          ? deleteObject(key).catch((err) => console.error("Failed to delete object from Garage:", err.message))
          : Promise.resolve();
      })
    );
    res.status(204).end();
  } catch {
    res.status(404).json({ error: "Bike not found" });
  }
}

export async function addColor(req, res) {
  const { name, hexCode } = req.body;
  if (!name || !hexCode) {
    return res.status(400).json({ error: "name and hexCode are required" });
  }
  const color = await prisma.bikeColor.create({
    data: { name, hexCode, bikeId: req.params.id },
  });
  res.status(201).json(color);
}

export async function deleteColor(req, res) {
  try {
    await prisma.bikeColor.delete({ where: { id: req.params.colorId } });
    res.status(204).end();
  } catch {
    res.status(404).json({ error: "Color not found" });
  }
}

export async function addImage(req, res) {
  const { url, colorId, isPrimary } = req.body;
  if (!url) return res.status(400).json({ error: "url is required" });

  if (isPrimary) {
    await prisma.bikeImage.updateMany({
      where: { bikeId: req.params.id },
      data: { isPrimary: false },
    });
  }

  const image = await prisma.bikeImage.create({
    data: {
      url,
      colorId: colorId ?? null,
      isPrimary: Boolean(isPrimary),
      bikeId: req.params.id,
    },
  });
  res.status(201).json(image);
}

export async function deleteImage(req, res) {
  try {
    const image = await prisma.bikeImage.delete({ where: { id: req.params.imageId } });
    const key = keyFromUrl(image.url);
    if (key) {
      await deleteObject(key).catch((err) => console.error("Failed to delete object from Garage:", err.message));
    }
    res.status(204).end();
  } catch {
    res.status(404).json({ error: "Image not found" });
  }
}
