import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../api/client";
import Loader from "../../components/ui/Loader";

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get("/bikes"), api.get("/enquiries")])
      .then(([bikesRes, enquiriesRes]) => {
        setStats({
          totalBikes: bikesRes.data.length,
          featured: bikesRes.data.filter((b) => b.featured).length,
          enquiries: enquiriesRes.data.length,
          recentEnquiries: enquiriesRes.data.slice(0, 5),
        });
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader />;

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-ink">Dashboard</h1>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Total Bikes" value={stats.totalBikes} />
        <StatCard label="Featured Bikes" value={stats.featured} />
        <StatCard label="Total Enquiries" value={stats.enquiries} />
      </div>

      <div className="mt-8 rounded-2xl border border-black/5 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-ink">Recent Enquiries</h2>
          <Link to="/admin/enquiries" className="text-sm font-semibold text-brand hover:underline">
            View all →
          </Link>
        </div>
        {stats.recentEnquiries.length === 0 ? (
          <p className="mt-4 text-sm text-ink-soft">No enquiries yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-black/5">
            {stats.recentEnquiries.map((e) => (
              <li key={e.id} className="py-3">
                <p className="text-sm font-semibold text-ink">{e.name} — {e.phone}</p>
                <p className="text-xs text-ink-soft">{e.bike ? `${e.bike.brand} ${e.bike.name}` : e.source}</p>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Link
        to="/admin/bikes/new"
        className="mt-8 inline-block rounded-full bg-brand px-6 py-3 text-sm font-bold uppercase tracking-wide text-white hover:bg-brand-dark"
      >
        + Add New Bike
      </Link>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="rounded-2xl border border-black/5 bg-white p-6 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft">{label}</p>
      <p className="mt-2 text-3xl font-black text-ink">{value}</p>
    </div>
  );
}
