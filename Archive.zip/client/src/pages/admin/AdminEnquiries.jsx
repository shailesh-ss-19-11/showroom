import { useEffect, useState } from "react";
import api from "../../api/client";
import Loader from "../../components/ui/Loader";

export default function AdminEnquiries() {
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    api.get("/enquiries").then((res) => setEnquiries(res.data)).finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function remove(id) {
    if (!confirm("Delete this enquiry?")) return;
    await api.delete(`/enquiries/${id}`);
    load();
  }

  if (loading) return <Loader />;

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-ink">Enquiries</h1>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-black/5 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-black/5 bg-gray-50 text-xs uppercase tracking-wide text-ink-soft">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3">Bike</th>
              <th className="px-4 py-3">Message</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-black/5">
            {enquiries.map((e) => (
              <tr key={e.id}>
                <td className="px-4 py-3 font-semibold text-ink">{e.name}</td>
                <td className="px-4 py-3 text-ink-soft">{e.phone}</td>
                <td className="px-4 py-3 text-ink-soft">{e.bike ? `${e.bike.brand} ${e.bike.name}` : "—"}</td>
                <td className="max-w-xs truncate px-4 py-3 text-ink-soft">{e.message || "—"}</td>
                <td className="px-4 py-3 text-ink-soft">{new Date(e.createdAt).toLocaleDateString("en-IN")}</td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => remove(e.id)} className="text-sm font-semibold text-red-600 hover:underline">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {enquiries.length === 0 && <p className="p-6 text-center text-sm text-ink-soft">No enquiries yet.</p>}
      </div>
    </div>
  );
}
