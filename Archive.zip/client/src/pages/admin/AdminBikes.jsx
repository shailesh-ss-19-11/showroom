import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { resolveImage } from "../../api/client";
import Loader from "../../components/ui/Loader";

function formatPrice(price) {
  return `₹${Number(price).toLocaleString("en-IN")}`;
}

export default function AdminBikes() {
  const [bikes, setBikes] = useState([]);
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    api.get("/bikes").then((res) => setBikes(res.data)).finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleDelete(id) {
    if (!confirm("Delete this bike? This cannot be undone.")) return;
    await api.delete(`/bikes/${id}`);
    load();
  }

  if (loading) return <Loader />;

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-ink">Bikes</h1>
        <Link
          to="/admin/bikes/new"
          className="rounded-full bg-brand px-5 py-2 text-sm font-bold uppercase tracking-wide text-white hover:bg-brand-dark"
        >
          + Add Bike
        </Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-black/5 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-black/5 bg-gray-50 text-xs uppercase tracking-wide text-ink-soft">
            <tr>
              <th className="px-4 py-3">Photo</th>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Brand</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Featured</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-black/5">
            {bikes.map((bike) => {
              const img = bike.images.find((i) => i.isPrimary) || bike.images[0];
              return (
                <tr key={bike.id}>
                  <td className="px-4 py-3">
                    <div className="h-12 w-16 overflow-hidden rounded-md bg-gray-100">
                      {img && <img src={resolveImage(img.url)} alt="" className="h-full w-full object-cover" />}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-semibold text-ink">
                    <Link to={`/admin/bikes/${bike.id}/view`} className="hover:text-brand hover:underline">
                      {bike.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-ink-soft">{bike.brand}</td>
                  <td className="px-4 py-3 text-ink-soft">{bike.category}</td>
                  <td className="px-4 py-3 text-ink-soft">{formatPrice(bike.price)}</td>
                  <td className="px-4 py-3">{bike.featured ? "✅" : "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <Link to={`/admin/bikes/${bike.id}/view`} className="mr-3 text-sm font-semibold text-ink hover:underline">
                      View
                    </Link>
                    <Link to={`/admin/bikes/${bike.id}`} className="mr-3 text-sm font-semibold text-brand hover:underline">
                      Edit
                    </Link>
                    <button onClick={() => handleDelete(bike.id)} className="text-sm font-semibold text-red-600 hover:underline">
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {bikes.length === 0 && <p className="p-6 text-center text-sm text-ink-soft">No bikes yet.</p>}
      </div>
    </div>
  );
}
